#include <cstdio>
#include "graphviewer.h"
#include <fstream>
#include <iostream>
#include <sstream>
#include <math.h>
#include <vector>

/**
 * Trata da anima��o do cami�o
 */
void animacao_camiao(vector<int>& vec, GraphViewer *gv)
{
	int id;
	for (int i = 0 ; i < vec.size(); i++)
	{
		id=vec[i];
		gv->setVertexSize(id, 20);
		gv->setVertexIcon(id, "icon.gif");
		gv->rearrange();
		Sleep(1000);
		gv->setVertexIcon(id, "nada.png");
		gv->setVertexColor(id, "CYAN");
		gv->rearrange();
	}
}

/**
 * Transforma a latitude e longitude para as coordenadas XY correspondentes no mapa.
 */
std::pair<double, double> long_and_lat_to_XY(double lat, double lon)
{
	std::pair<double, double> res;

	double zoom = 15; //Zoom usado no mapa retirado

	double lat_rad = 41.1886 * M_PI / 180;
	double n = pow(2.0, zoom);

	double cantoX = ((-8.3076 + 180) / 360) * n;
	double cantoY = (1 - (log(tan(lat_rad) + 1.0 / cos(lat_rad)) / M_PI)) * n/ 2.0;
//_________________________

	lat_rad = lat * M_PI / 180;
	double tileX = ((lon + 180) / 360) * n;
	double tileY = (1 - (log(tan(lat_rad) + 1.0 / cos(lat_rad)) / M_PI)) * n/ 2.0;

	tileX=cantoX-tileX;
	tileY=cantoY-tileY;
//________________________

	double pixeisX=tileX*256;
	double pixeisY=tileY*256;

	//----
	pixeisX = pixeisX * -2;
	pixeisY = pixeisY * -2;

	//cout << "x: "<< pixeisX << "  y: " << pixeisY << "\n";
	res.first=pixeisX;
	res.second=pixeisY;

	return res;
}

/**
 * Mostra o mapa, assim como o caminho (caminho.txt) mais curto, que foi calculado previamente, e a anima��o de um cami�o a percorrer o caminho.
 */
void mostrar()
{
	GraphViewer *gv = new GraphViewer(807, 949, false);
	gv->defineEdgeCurved(false);
	gv->defineVertexSize(10);
	gv->setBackground("background.png");
	gv->createWindow(807, 949);

	gv->defineEdgeColor("blue");
	gv->defineVertexColor("yellow");


	//___________________________________
	pair<double, double> pontos;
	ifstream inFile;

	inFile.open("map1.txt");

	if (!inFile) {
		cerr << "Unable to open file datafile.txt";
		exit(1);   // call system to stop
	}

	string line;

	int idNo = 0;
	double latitude = 0;
	double longitude = 0;
	double dummy;

	while (std::getline(inFile, line))
	{
		stringstream linestream(line);
		string data;

		linestream >> idNo;
		getline(linestream, data, ';');
		linestream >> latitude;
		getline(linestream, data, ';');
		linestream >> longitude;
		getline(linestream, data, ';');
		linestream >> dummy;
		getline(linestream, data, ';');
		linestream >> dummy;


		pontos = long_and_lat_to_XY(latitude, longitude);
		gv->addNode(idNo,pontos.first, pontos.second);
	}
	inFile.close();
//____________________________________________


	int idNo2;
	string data;

	inFile.open("caminho.txt");
	if (!inFile)
	{
		cerr << "Unable to open file caminho.txt";
		cin.get();
		exit(1);
	}

	vector<int> caminho;

	inFile >> idNo;
	caminho.push_back(idNo);
	while (!inFile.eof())
	{
		inFile >> idNo;
		caminho.push_back(idNo);
	}
	inFile.close();

//_________________________________
	if(caminho.size()==0)
	{
		cout << "NAO EXISTE CAMINHO A PROCESSAR";~
		cin.get();
		return;
	}


	//Mostrar caminho
	idNo=caminho[0];
	for(int i=1; i< caminho.size(); i++)
	{
		if(i>1)
			idNo=idNo2;

		idNo2=caminho[i];
		gv->addEdge(i-1, idNo, idNo2, EdgeType::UNDIRECTED);
		gv->setEdgeThickness(i-1, 10);
	}
	animacao_camiao(caminho, gv);
//________________________________________________
}

int main()
{
	mostrar();
	getchar();
	return 0;
}
