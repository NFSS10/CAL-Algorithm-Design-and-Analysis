var searchData=
[
  ['city',['City',['../class_city.html',1,'']]],
  ['company',['Company',['../class_company.html',1,'']]]
];
