var indexSectionsWithContent =
{
  0: "acdegilmorstv~",
  1: "acegilmtv",
  2: "cilmst",
  3: "acdegilmorst~"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions"
};

