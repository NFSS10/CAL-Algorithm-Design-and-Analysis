var searchData=
[
  ['deliveryitems',['deliveryItems',['../class_truck.html#abdb9bfa6b9601f13a46df7f09c16c17a',1,'Truck']]]
];
